using TMPro;
using UnityEngine;
using System;

public class Drop1 : MonoBehaviour
{
    public TextMeshProUGUI Operation;
    public int RESULT = 0;
    public int result = 0;
    string numberString;
    void Start()
    {
        NumberGenerator();


    }

    // Update is called once per frame
    void Update()
    {


        if (transform.position.y <= -4)
        {
            GameController.Instance.Lives = GameController.Instance.Lives - 1;
            Destroy(gameObject);
            NumberGenerator();

        }
        else
        {
            if (RESULT == result)
            {
                GameObject[] allObjects = FindObjectsOfType<GameObject>();

                // Distruggi tutti gli oggetti che hanno un componente CircleComponent
                foreach (GameObject obj in allObjects)
                {
                    if (obj.GetComponent<CircleCollider2D>() != null)
                    {
                        GameController.Instance.goldendropScore = GameController.Instance.goldendropScore + 30;
                       
                        
                        Destroy(obj);

                    }
                }


            }
        }

        Keyboard();


    }
    void NumberGenerator()
    {
        int a;
        int b;
        b = UnityEngine.Random.Range(0, 11);
        string B = Convert.ToString(b, 2).PadLeft(4, '0'); ;
        a = UnityEngine.Random.Range(0, 11);
        string A = Convert.ToString(a, 2).PadLeft(4, '0'); ;
        Operator(a, b, A, B);
       
    }

    void Operator(int i, int j, string k, string h)
    {

            RESULT = i + j;
            Operation.SetText(k + "+" + h);
        



    }
    void Keyboard()
    {
        if (Input.GetKeyDown(KeyCode.Alpha0))
        {
            numberString += "0";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            numberString += "1";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            numberString += "2";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            numberString += "3";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            numberString += "4";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            numberString += "5";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            numberString += "6";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            numberString += "7";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha8))
        {
            numberString += "8";
            //Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha9))
        {
            numberString += "9";
            //Result.SetText(numberString);
        }


        if (Input.GetKeyDown(KeyCode.Return))
        {
            result = int.Parse(numberString);
            numberString = "";
            //Result.SetText(numberString); // Reset the number string
        }
    }

}
