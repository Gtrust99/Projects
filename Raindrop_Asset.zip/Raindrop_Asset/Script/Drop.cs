using TMPro;
using UnityEngine;

public class Drop : MonoBehaviour
{
    public TextMeshProUGUI Operation;
    public TextMeshProUGUI Result;
    public int RESULT;
    public  int result;
    float pickdestroy;
    string numberString;
    public GameObject gocce;

    void Start()
    {
        NumberGenerator();
    }

    // Update is called once per frame
    void Update()
    {

        if(RESULT==result)
        {
            GameController.Instance.normaldropScore = GameController.Instance.normaldropScore + 20;
            Destroy(gameObject);
            Instantiate(gocce, gameObject.transform.position, gameObject.transform.rotation);
            NumberGenerator();
        }
        
        if (transform.position.y <=pickdestroy)
        {
            Destroy(gameObject);
            NumberGenerator();
        }
        if (transform.position.y <= -4)
        {
            GameController.Instance.Lives = GameController.Instance.Lives - 1;
            Vector3 newScale = UIcontroller.Instance.Image.transform.localScale;
            newScale.y = newScale.y+0.05f; // Imposta la scala desiderata sull'asse Y
            UIcontroller.Instance.Image.transform.localScale = newScale;
            UIcontroller.Instance.Image.transform.localScale=newScale;
            Destroy(gameObject);
            pickdestroy = Random.Range(-4, 0);
            Instantiate(gocce, gameObject.transform.position, gameObject.transform.rotation);
            NumberGenerator();
            NumberGenerator();
        }
        Keyboard();

        if(GameController.Instance.totalscore>= GameController.Instance.breakerscore)
        {
            GameController.Instance.limitA = GameController.Instance.limitA + 2;
            GameController.Instance.limitB = GameController.Instance.limitB + 2;
            GameController.Instance.breakerscore= GameController.Instance.breakerscore+750;
        }

    }
    void NumberGenerator()
    {
        int a;
        int b;
        b = (int)Random.Range(GameController.Instance.limitA, GameController.Instance.limitB);
        a = b+ (int)Random.Range(GameController.Instance.limitA, GameController.Instance.limitB);
        Operator(a,b);
        pickdestroy= Random.Range(-5, 0);
    }

    void Operator(int i , int j)
    {
        int OP;
        OP = Random.Range(0,4);
        if(OP==0)
        {
            RESULT = i + j;
            Operation.SetText(i+"+"+j);
        }
        if (OP == 1)
        {
            RESULT = i - j;
            Operation.SetText(i + "-" + j);
        }
        if (OP == 2)
        {
            RESULT = i * j;
            Operation.SetText(i + "x" + j);
        }
        if (OP == 3)
        {
            int n;
            int m;
            n = i / j;
            if(n!=0)
            {
                m = Random.Range(0,10);
                i = m * j;
            }
            RESULT = i / j;
            Operation.SetText(i + ":" + j);
        }

    }
    void Keyboard()
    {
        if (Input.GetKeyDown(KeyCode.Alpha0))
        {
            numberString += "0";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            numberString += "1";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            numberString += "2";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            numberString += "3";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            numberString += "4";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha5))
        {
            numberString += "5";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha6))
        {
            numberString += "6";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha7))
        {
            numberString += "7";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha8))
        {
            numberString += "8";
            Result.SetText(numberString);
        }
        if (Input.GetKeyDown(KeyCode.Alpha9))
        {
            numberString += "9";
            Result.SetText(numberString);
        }


        if (Input.GetKeyDown(KeyCode.Return))
        {
            result = int.Parse(numberString);
            numberString = "";
            Result.SetText("");// Reset the number string
        }
    }

}
